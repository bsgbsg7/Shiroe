#ifndef _CTIIC_H_
#define _CTIIC_H_
#include "lcd_init.h"
#include "REG51.h"

#define TOUCH_MAX 5
 
sbit GT_IIC_SCL = P3^6;			//SCL     
sbit GT_IIC_SDA = P3^4;			//SDA	 

sbit RST_CTRL = P0^2;	//GT911 RESET pin out high or low
sbit INT_CTRL = P0^0; //GT911 INT pin out high or low



#define GT911_IIC_RADDR 0xBB	//IIC read address, should be 0x29
#define GT911_IIC_WADDR 0xBA	//IIC write address, should be 0x28

#define GT911_READ_ADDR 0x814E	//touch point information
#define GT911_ID_ADDR 0x8140		//ID of touch IC

void GT_IIC_Init(void);                	//��ʼ��IIC��IO��				 
void GT_IIC_Start(void);				//����IIC��ʼ�ź�
void GT_IIC_Stop(void);	  				//����IICֹͣ�ź�
void GT_IIC_Send_Byte(u8 txd);			//IIC����һ���ֽ�
u8 GT_IIC_Read_Byte(unsigned char ack);	//IIC��ȡһ���ֽ�
u8 GT_IIC_Wait_Ack(void); 				//IIC�ȴ�ACK�ź�
void GT_IIC_Ack(void);					//IIC����ACK�ź�
void GT_IIC_NAck(void);					//IIC������ACK�ź�

void GT911_int_sync(u16 ms);
void GT911_reset_guitar(u8 addr);
void GT911_gpio_init(void);
u8 GT9XX_WriteHandle (u16 addr);
u8 GT9XX_WriteData (u16 addr,u8 value);
u8 GT9XX_ReadData (u16 addr, u8 cnt, u8 *value);
u8 GT911_Init(void);
u8 Touch_Get_Count(void);
u8 GT911_Scan(void);
void GT9xx_send_config(void);
void GT9xx_Eint_Init(void);

#endif

