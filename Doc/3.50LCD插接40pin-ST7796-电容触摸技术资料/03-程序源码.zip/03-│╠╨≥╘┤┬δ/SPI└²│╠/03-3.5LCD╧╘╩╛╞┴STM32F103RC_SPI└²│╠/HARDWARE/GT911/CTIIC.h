#ifndef _CTIIC_H_
#define _CTIIC_H_
#include "sys.h"

#define TOUCH_MAX 5
 
//IO��������
#define CT_SDA_IN()  {GPIOB->CRH&=0XFFFFFFF0;GPIOB->CRH|=0x00000008;}
#define CT_SDA_OUT() {GPIOB->CRH&=0XFFFFFFF0;GPIOB->CRH|=0x00000003;}


#define RST_OUT()	{	GPIOD->CRL&=0XFFFFF0FF;GPIOB->CRL|=0X00000300;}		//set RSSET pin to output

#define INT_OUT()	{	GPIOB->CRH&=0XFFFFFF0F;GPIOB->CRH|=0X00000030;}		//set RSSET pin to output
#define INT_IN()	{	GPIOB->CRH&=0XFFFFFF0F;GPIOB->CRH|=0X00000030;}		//set RSSET pin to output



//IO��������	 
#define CT_IIC_SCL    PBout(7) 			//SCL   

#define CT_IIC_SDA    PBout(8) 			//SDA	 
#define CT_READ_SDA   PBin(8)  			//����SDA 

#define RST_CTRL   		PDout(2)	//GT911 RESET pin out high or low

#define INT_CTRL   		PBout(9) 	//GT911 INT pin out high or low
#define INT_GET   		PBin(9) 	//Get GT911 INT pin status


#define GT911_IIC_RADDR 0xBB	//IIC read address, should be 0x29
#define GT911_IIC_WADDR 0xBA	//IIC write address, should be 0x28

#define GT911_READ_ADDR 0x814E	//touch point information
#define GT911_ID_ADDR 0x8140		//ID of touch IC



void CT_IIC_Init(void);                	//��ʼ��IIC��IO��				 
void CT_IIC_Start(void);				//����IIC��ʼ�ź�
void CT_IIC_Stop(void);	  				//����IICֹͣ�ź�
void CT_IIC_Send_Byte(u8 txd);			//IIC����һ���ֽ�
u8 CT_IIC_Read_Byte(unsigned char ack);	//IIC��ȡһ���ֽ�
u8 CT_IIC_Wait_Ack(void); 				//IIC�ȴ�ACK�ź�
void CT_IIC_Ack(void);					//IIC����ACK�ź�
void CT_IIC_NAck(void);					//IIC������ACK�ź�

void GT911_int_sync(u16 ms);
void GT911_reset_guitar(u8 addr);
void GT911_gpio_init(void);
u8 GT911_WriteHandle (u16 addr);
u8 GT911_WriteData (u16 addr,u8 value);
u8 GT911_ReadData (u16 addr, u8 cnt, u8 *value);
u8 GT911_Init(void);
u8 Touch_Get_Count(void);
u8 GT911_Scan(u8 mode);
void GT911_send_config(void);
void GT911_Eint_Init(void);

#endif

